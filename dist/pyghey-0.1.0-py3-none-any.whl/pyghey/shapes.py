from .individuals import print_cross,print_none

def logger_cow(message):
    print_none(10)
    print(f"MOO: {message}")
    print_none(10)
    print("______")
    print("< ____ >")
    print("( ^ - ^ )")
    print(" > ^ <")