def print_line(count=10):
    print("-" * count)

def print_none(count=10):
    print(" " * count)

def print_hash(count=10):
    print("#" * count)

def print_cross(count=10):
    print("X" * count)

def break_line(count=2):
    print("\n" * count)